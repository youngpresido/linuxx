from django import forms

from .models import ScrummyUser

class UserForm(forms.ModelForm):
    first_name = forms.CharField(max_length=20)
    last_name = forms.CharField(max_length=20)
    roles = forms.ChoiceField(choices=ScrummyUser.ROLES)


    class Meta:
        model = ScrummyUser
        fields = ('first_name', 'last_name', 'roles')
