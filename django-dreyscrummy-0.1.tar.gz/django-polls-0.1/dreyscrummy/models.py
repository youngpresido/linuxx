from django.db import models

from datetime import datetime


class ScrummyUser(models.Model):
    ROLES=(
        ("OWNER", "Owner"),
        ("ADMIN", "Admin"),
        ("QUALITY ANALYST", "Quality Analyst"),
        ("DEVELOPER", "Developer")
    )
    first_name = models.CharField(max_length=40)
    last_name = models.CharField(max_length=40)
    roles = models.CharField(max_length=15, choices=ROLES)

    def __str__(self):
        return self.first_name + '  ' + self.last_name


class ScrummyGoals(models.Model):
    user = models.ForeignKey(ScrummyUser, on_delete=models.CASCADE)
    goals = models.CharField(max_length=200)
    pub_date = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.goals

class GoalStatus(models.Model):
    STATUS=(
        ("Initialize", "Initialize"),
        ("Pending", "Pending"),
        ("Done", "Done")
    )
    goals = models.OneToOneField(ScrummyGoals, on_delete=models.CASCADE)
    daily_target = models.CharField(max_length=50, blank=True)
    weekly_target = models.CharField(max_length=50, blank=True)
    verified = models.BooleanField(default=False, blank=True)
    status = models.CharField(max_length=10, choices=STATUS)

    def __str__(self):
        return self.daily_target + ' - ' + self.status
