from django.apps import AppConfig


class DreyscrummyConfig(AppConfig):
    name = 'dreyscrummy'
