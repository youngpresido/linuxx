from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST

from .forms import UserForm
from .models import ScrummyGoals, ScrummyUser, GoalStatus

# Display list of Goals
def index(request):
    latest_goalstatus_list = GoalStatus.objects.all()

    context = {'latest_goalstatus_list': latest_goalstatus_list,}
    return render(request, 'dreyscrummy/index.html', context)


def move_goal(request, goals_id):
    return HttpResponse("You're looking at my goals %s." % goals_id)

# Registered Users Views and Form Display
def adduser(request):
    latest_scrummyuser_list = ScrummyUser.objects.all()

    form = UserForm()


    context = {'latest_scrummyuser_list': latest_scrummyuser_list, 'form' : form}
    return render(request, 'adduser.html', context)

# Adding new user to the database and displaying them 
@require_POST
def add_user(request):
    form = UserForm(request.POST)

    if form.is_valid():

        form.save()

    return redirect('adduser')
