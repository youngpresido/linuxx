from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('<int:goals_id>/', views.move_goal, name='move_goal'),
    path('adduser/', views.adduser, name='adduser'),
    path('add/', views.add_user, name='add',)

]
