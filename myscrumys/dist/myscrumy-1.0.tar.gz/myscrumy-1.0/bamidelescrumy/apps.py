from django.apps import AppConfig


class BamidelescrumyConfig(AppConfig):
    name = 'bamidelescrumy'
