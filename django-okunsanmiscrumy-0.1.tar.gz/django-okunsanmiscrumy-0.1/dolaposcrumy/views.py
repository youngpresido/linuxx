from django.template import loader
from  django.shortcuts import render, get_object_or_404 #second way to handle errors
from django.http import HttpResponse, Http404
from .models import ScrumyGoals, ScrumyUser

# Create your views here.
# def index(request):
# return HttpResponse('<h1>Hello World!</h1>')

def homepage(request):
    try:
        scrumy_goals = ScrumyGoals.objects.get(pk=2)
        context = {'scrumy_goals': scrumy_goals}
        template = loader.get_template('dolaposcrumy/home.html')
        return HttpResponse(template.render(context, request))
    except ScrumyGoals.DoesNotExist:
        raise Http404("User does not exist")

            #OR
    # scrumy_goals = get_object_or_404(ScrumyGoals, pk=5)
    # return render(request, 'dolaposcrumy/home.html', {'scrumy_goals':scrumy_goals})


def home(request):
    a = ScrumyGoals.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse('Hello %s please edit or add a new task' %usersView)

def addUser(request):
    user = ScrumyUser(userName = 'mike')
    user.save()
    users = ScrumyUser.objects.all()
    output = ', '.join([eachuser.userName for eachuser in users])
    return HttpResponse(output)



