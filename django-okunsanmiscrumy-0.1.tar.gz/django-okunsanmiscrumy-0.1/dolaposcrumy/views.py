from django.template import loader
from django.http import HttpResponse
from .models import ScrumyGoals, ScrumyUser


# Create your views here.
# def index(request):
#     return HttpResponse('<h1>Hello World!</h1>')


def homepage(request):
    scrumy_goals = ScrumyGoals.objects.get(pk=3)
    context = {'scrumy_goals': scrumy_goals}
    template = loader.get_template ('dolaposcrumy/home.html')
    return HttpResponse(template.render(context, request))


def home(request):
    a = ScrumyGoals.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse('Hello %s please edit or add a new task' %usersView )

def addUser(request):
    user = ScrumyUser(userName = 'mike')
    user.save()
    users = ScrumyUser.objects.all()
    output = ', '.join([eachuser.userName for eachuser in users])
    return HttpResponse(output)


