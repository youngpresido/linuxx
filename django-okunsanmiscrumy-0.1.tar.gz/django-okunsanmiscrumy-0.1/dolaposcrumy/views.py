from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render, HttpResponse
from .models import ScrumyGoals, ScrumyUser


# Create your views here.
def homepage(request):
    return HttpResponse('<h1>Hello World!</h1>')
  

def homepage(request):
    a = ScrumyGoals.objects.all()
    return HttpResponse(a)


def homepage(request):
    a = ScrumyGoals.objects.all().filter(task_category='daily goals')
    return HttpResponse(a)

def addTask(request,usersView):
    return HttpResponse('Hello %s please edit or add a new task' %usersView )
