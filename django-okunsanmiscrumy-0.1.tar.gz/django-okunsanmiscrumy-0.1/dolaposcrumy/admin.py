from django.contrib import admin
from .models import ScrumyGoals, ScrumyUser

# Register your models here.

admin.site.register(ScrumyUser)
admin.site.register(ScrumyGoals)
