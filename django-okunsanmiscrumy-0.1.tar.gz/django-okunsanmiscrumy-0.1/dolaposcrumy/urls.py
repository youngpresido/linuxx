from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
    path('', views.homepage, name = 'homepage'),
    # path('dolaposcrumy/homepage', views.homepage, name='homepage'),
    path('<str:usersView>/', views.addTask, name='addTask'),
]
