from django.urls import path
from django.conf.urls import url
from . import views
app_name = 'dolaposcrumy'

urlpatterns = [
    # path('', views.index, name = 'index'),
    path('', views.homepage, name='homepage'),
    path('home/', views.home, name='home'),
    path('<str:usersView>/', views.addTask, name='addTask'),
    path('user/addUser', views.addUser, name='addUser'),


]
